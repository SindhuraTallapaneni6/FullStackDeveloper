/**
 * @license Highcharts JS v8.0.3 (2020-03-05)
 * @module highcharts/themes/sand-signika
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/sand-signika.js';
