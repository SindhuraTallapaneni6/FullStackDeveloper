export class Ipo{
    id:number;
    exchangename:string;
    brief: string;
    pricepershare :number;
    remarks: String;
    stockexchange: string;
    totalstocks:number;

}