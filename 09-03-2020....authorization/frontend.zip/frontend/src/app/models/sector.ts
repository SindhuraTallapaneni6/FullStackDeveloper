export class Sector
{
    id: number;
    name: string;
    breif: string;
}

