export class Company
{
    id:number;
    companyname:string;
    ceo: string;
    bod :string;
    turnover: number;
    sector: string;
    
    
    
    
}