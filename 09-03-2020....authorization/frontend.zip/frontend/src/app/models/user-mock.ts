// import { User} from './user';

// export const USERS: User[]= [
//     { id: 101, fname: 'sindhu', lname:'Tallapaneni', uname:'sindhu123', email:'tanu@gamil.com', rpwd:'12345', repwd :'12345', phone:99999999, otp:4535},
//     { id: 102,fname: 'Malavika', lname:'Unni',uname:'malavika123', email:'malavika@gamil.com', rpwd:'15463', repwd :'15463', phone:994783875, otp:4555},
//     { id: 103,fname: 'Tanu', lname:'Sree',uname:'tanu123', email:'tanu@gamil.com', rpwd:'12356', repwd :'12356', phone:99999998, otp:4536},
//     { id: 104,fname: 'Sairam', lname:'Jagadam',uname:'sai123', email:'sai@gamil.com', rpwd:'12347', repwd :'12347', phone:99999997, otp:4537},
//     { id: 105,fname: 'Divya', lname:'Kolla',uname:'divya123', email:'divya@gamil.com', rpwd:'12348', repwd :'12348', phone:99999998, otp:4538},




// ];
