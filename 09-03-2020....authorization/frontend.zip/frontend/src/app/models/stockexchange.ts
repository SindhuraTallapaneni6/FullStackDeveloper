export class StockExchange{
    id:number;
    exchangename:string;
    brief: string; 
    contactaddress: String;
    remarks: string;
    

}