export class User
{
    id: number;
    fname: string;
    lname: string;
    username: string;
    email: string;
    password: string;
    repassword:string;
    phone: number;
    otp: number;
    // regStatus: String;
    active: boolean;
   
}