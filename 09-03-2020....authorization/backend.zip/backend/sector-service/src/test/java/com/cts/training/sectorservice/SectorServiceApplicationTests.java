package com.cts.training.sectorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SectorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
