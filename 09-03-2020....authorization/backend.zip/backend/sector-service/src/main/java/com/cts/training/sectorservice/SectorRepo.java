package com.cts.training.sectorservice;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.training.sectorservice.Sector;

public interface SectorRepo extends JpaRepository<Sector, Integer>{

}
